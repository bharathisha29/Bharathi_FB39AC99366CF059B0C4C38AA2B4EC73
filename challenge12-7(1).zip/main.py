num= int(input("Enter the year"))
if num%4==0:
  print("The year is leap year",num)
else:
  print("The year is not leap year",num)